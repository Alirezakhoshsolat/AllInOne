def subtract(x, y):
    r = x - y
    print(r)