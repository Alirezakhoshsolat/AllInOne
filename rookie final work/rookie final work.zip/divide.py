def divide(x, y):
    r = x / y
    print(r)