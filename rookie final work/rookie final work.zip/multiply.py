def multiply(x, y):
    r = x * y
    print(r)